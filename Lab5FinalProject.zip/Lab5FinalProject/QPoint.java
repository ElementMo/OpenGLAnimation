public class QPoint {
    float x, y;
    int index;

    QPoint(float x, float y, int index) {
        this.x = x;
        this.y = y;
        this.index = index;
    }
}